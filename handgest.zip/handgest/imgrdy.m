function imgtemp=imgrdy(img);


I=img(:,[21:140]);
I3 = skin(I);%sobel edge dnnetection
se = strel('line',5,90);
I4 = imdilate(I3,se);
I4=imresize(I4,0.25);
imgtemp=reshape(I3,[],1);

end